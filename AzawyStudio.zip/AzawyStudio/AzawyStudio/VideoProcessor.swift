import Foundation
import AVFoundation
import CoreImage
import Vision
import UIKit

enum VideoProcessorError: Error {
    case cannotReadVideo
    case cannotCreateWriter
    case noVideoTrack
}

final class VideoProcessor {

    private let ciContext = CIContext(options: [.useSoftwareRenderer: false])

    /// يعالج الفيديو: يعزل الخلفية عبر Vision (كما تفعل كاميرات الآيفون الاحترافية)
    /// ثم يطبّق فلتر LUT سينمائي، ويعيد رابط الفيديو الناتج.
    func process(
        inputURL: URL,
        lutFilter: CIFilter?,
        isolateBackground: Bool,
        blurRadius: Double,
        progress: @escaping (Double) -> Void
    ) async throws -> URL {

        let asset = AVURLAsset(url: inputURL)
        guard let videoTrack = try await asset.loadTracks(withMediaType: .video).first else {
            throw VideoProcessorError.noVideoTrack
        }

        let naturalSize = try await videoTrack.load(.naturalSize)
        let transform = try await videoTrack.load(.preferredTransform)
        let nominalFrameRate = try await videoTrack.load(.nominalFrameRate)
        let duration = try await asset.load(.duration)
        let totalSeconds = max(CMTimeGetSeconds(duration), 0.01)

        // الحجم الفعلي للفيديو بعد تطبيق دورانه (portrait/landscape)
        let renderSize = naturalSize.applying(transform).applyingAbsoluteSize()

        let outputURL = FileManager.default.temporaryDirectory
            .appendingPathComponent(UUID().uuidString)
            .appendingPathExtension("mp4")

        // ---------- المرحلة 1: معالجة إطارات الفيديو ----------
        try await renderVideoTrack(
            asset: asset,
            videoTrack: videoTrack,
            transform: transform,
            renderSize: renderSize,
            nominalFrameRate: nominalFrameRate,
            outputURL: outputURL,
            lutFilter: lutFilter,
            isolateBackground: isolateBackground,
            blurRadius: blurRadius,
            totalSeconds: totalSeconds,
            progress: progress
        )

        // ---------- المرحلة 2: نسخ الصوت الأصلي إن وجد ----------
        if let audioTrack = try await asset.loadTracks(withMediaType: .audio).first {
            let finalURL = try await muxAudio(
                videoURL: outputURL,
                sourceAsset: asset,
                audioTrack: audioTrack
            )
            try? FileManager.default.removeItem(at: outputURL)
            return finalURL
        }

        return outputURL
    }

    // MARK: - معالجة إطارات الفيديو

    private func renderVideoTrack(
        asset: AVURLAsset,
        videoTrack: AVAssetTrack,
        transform: CGAffineTransform,
        renderSize: CGSize,
        nominalFrameRate: Float,
        outputURL: URL,
        lutFilter: CIFilter?,
        isolateBackground: Bool,
        blurRadius: Double,
        totalSeconds: Double,
        progress: @escaping (Double) -> Void
    ) async throws {

        let reader = try AVAssetReader(asset: asset)
        let readerOutputSettings: [String: Any] = [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA
        ]
        let trackOutput = AVAssetReaderTrackOutput(track: videoTrack, outputSettings: readerOutputSettings)
        trackOutput.alwaysCopiesSampleData = false
        guard reader.canAdd(trackOutput) else { throw VideoProcessorError.cannotReadVideo }
        reader.add(trackOutput)

        let writer = try AVAssetWriter(outputURL: outputURL, fileType: .mp4)
        let width = Int(renderSize.width.rounded())
        let height = Int(renderSize.height.rounded())

        let writerInputSettings: [String: Any] = [
            AVVideoCodecKey: AVVideoCodecType.h264,
            AVVideoWidthKey: width,
            AVVideoHeightKey: height
        ]
        let writerInput = AVAssetWriterInput(mediaType: .video, outputSettings: writerInputSettings)
        writerInput.expectsMediaDataInRealTime = false

        let attrs: [String: Any] = [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
            kCVPixelBufferWidthKey as String: width,
            kCVPixelBufferHeightKey as String: height
        ]
        let adaptor = AVAssetWriterInputPixelBufferAdaptor(assetWriterInput: writerInput, sourcePixelBufferAttributes: attrs)

        guard writer.canAdd(writerInput) else { throw VideoProcessorError.cannotCreateWriter }
        writer.add(writerInput)

        guard reader.startReading() else { throw VideoProcessorError.cannotReadVideo }
        guard writer.startWriting() else { throw VideoProcessorError.cannotCreateWriter }
        writer.startSession(atSourceTime: .zero)

        let segmentationRequest = VNGeneratePersonSegmentationRequest()
        segmentationRequest.qualityLevel = .balanced
        segmentationRequest.outputPixelFormat = kCVPixelFormatType_OneComponent8

        while let sampleBuffer = trackOutput.copyNextSampleBuffer() {
            guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { continue }
            let pts = CMSampleBufferGetPresentationTimeStamp(sampleBuffer)

            var ciImage = CIImage(cvPixelBuffer: pixelBuffer).transformed(by: transform)
            // إعادة الإطار لتبدأ إحداثياته من الصفر بعد الدوران
            ciImage = ciImage.transformed(by: CGAffineTransform(translationX: -ciImage.extent.origin.x, y: -ciImage.extent.origin.y))

            if isolateBackground {
                ciImage = try applyBackgroundIsolation(
                    to: pixelBuffer,
                    orientedImage: ciImage,
                    transform: transform,
                    request: segmentationRequest,
                    blurRadius: blurRadius
                )
            }

            if let lutFilter = lutFilter {
                lutFilter.setValue(ciImage, forKey: kCIInputImageKey)
                if let out = lutFilter.outputImage {
                    ciImage = out.cropped(to: ciImage.extent)
                }
            }

            guard let pool = adaptor.pixelBufferPool else { continue }
            var newBufferOpt: CVPixelBuffer?
            CVPixelBufferPoolCreatePixelBuffer(nil, pool, &newBufferOpt)
            guard let newBuffer = newBufferOpt else { continue }

            ciContext.render(ciImage, to: newBuffer)

            while !writerInput.isReadyForMoreMediaData {
                usleep(2000)
            }
            adaptor.append(newBuffer, withPresentationTime: pts)

            let seconds = CMTimeGetSeconds(pts)
            progress(min(seconds / totalSeconds, 0.98))
        }

        writerInput.markAsFinished()
        await writer.finishWriting()
        reader.cancelReading()
    }

    /// يستخدم Vision لعزل الشخص عن الخلفية، ثم يموّه الخلفية فقط (محاكاة عمق ميدان ضحل).
    private func applyBackgroundIsolation(
        to pixelBuffer: CVPixelBuffer,
        orientedImage: CIImage,
        transform: CGAffineTransform,
        request: VNGeneratePersonSegmentationRequest,
        blurRadius: Double
    ) throws -> CIImage {
        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])
        try handler.perform([request])

        guard let maskBuffer = request.results?.first?.pixelBuffer else {
            return orientedImage
        }

        var maskImage = CIImage(cvPixelBuffer: maskBuffer)
        // تكبير القناع ليطابق أبعاد الصورة الأصلية، ثم تدويره بنفس اتجاه الفيديو
        let scaleX = orientedImage.extent.width / maskImage.extent.width
        let scaleY = orientedImage.extent.height / maskImage.extent.height
        maskImage = maskImage.transformed(by: CGAffineTransform(scaleX: scaleX, y: scaleY))
        maskImage = maskImage.applyingGaussianBlur(sigma: 4)

        let blurred = orientedImage
            .clampedToExtent()
            .applyingGaussianBlur(sigma: blurRadius)
            .cropped(to: orientedImage.extent)

        guard let blend = CIFilter(name: "CIBlendWithMask") else { return orientedImage }
        blend.setValue(orientedImage, forKey: kCIInputImageKey)
        blend.setValue(blurred, forKey: kCIInputBackgroundImageKey)
        blend.setValue(maskImage, forKey: kCIInputMaskImageKey)
        return blend.outputImage?.cropped(to: orientedImage.extent) ?? orientedImage
    }

    // MARK: - دمج الصوت الأصلي

    private func muxAudio(videoURL: URL, sourceAsset: AVURLAsset, audioTrack: AVAssetTrack) async throws -> URL {
        let mixedURL = FileManager.default.temporaryDirectory
            .appendingPathComponent(UUID().uuidString)
            .appendingPathExtension("mp4")

        let composition = AVMutableComposition()
        let videoAsset = AVURLAsset(url: videoURL)

        guard let compVideoTrack = composition.addMutableTrack(withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid),
              let sourceVideoTrack = try await videoAsset.loadTracks(withMediaType: .video).first else {
            return videoURL
        }
        let videoDuration = try await videoAsset.load(.duration)
        try compVideoTrack.insertTimeRange(CMTimeRange(start: .zero, duration: videoDuration), of: sourceVideoTrack, at: .zero)

        if let compAudioTrack = composition.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid) {
            let audioDuration = try await sourceAsset.load(.duration)
            let range = CMTimeRange(start: .zero, duration: min(audioDuration, videoDuration))
            try? compAudioTrack.insertTimeRange(range, of: audioTrack, at: .zero)
        }

        guard let export = AVAssetExportSession(asset: composition, presetName: AVAssetExportPresetHighestQuality) else {
            return videoURL
        }
        export.outputURL = mixedURL
        export.outputFileType = .mp4

        await export.export()
        if export.status == .completed {
            return mixedURL
        }
        return videoURL
    }
}

private extension CGSize {
    /// يضمن أبعادًا موجبة بعد تطبيق مصفوفة الدوران (transform) على أبعاد الفيديو الأصلية.
    func applyingAbsoluteSize() -> CGSize {
        CGSize(width: abs(width), height: abs(height))
    }
}
