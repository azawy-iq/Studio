import Foundation
import CoreImage

/// يمثل فلترًا سينمائيًا واحدًا (ملف .cube)
struct LUTInfo: Identifiable, Hashable {
    let id = UUID()
    let name: String
    let url: URL
}

enum LUTManager {

    /// مجلد LUTs الخاص بالمستخدم داخل Documents — تظهر ملفاته في تطبيق "الملفات"
    /// (على جهازي > Azawy Studio > LUTs) بفضل UIFileSharingEnabled.
    static var userLUTsFolder: URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let folder = docs.appendingPathComponent("LUTs", isDirectory: true)
        if !FileManager.default.fileExists(atPath: folder.path) {
            try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        }
        return folder
    }

    /// يكتشف كل ملفات .cube الموجودة داخل حزمة التطبيق (Bundle) ومجلد المستخدم في Documents،
    /// دون أي تعديل على الكود عند إضافة فلاتر جديدة.
    static func discoverLUTs() -> [LUTInfo] {
        var results: [LUTInfo] = []

        // 1) فلاتر مدمجة مع التطبيق (AzawyStudio/LUTs في المشروع)
        if let bundled = Bundle.main.urls(forResourcesWithExtension: "cube", subdirectory: nil) {
            for url in bundled {
                results.append(LUTInfo(name: url.deletingPathExtension().lastPathComponent, url: url))
            }
        }

        // 2) فلاتر أضافها المستخدم عبر تطبيق الملفات
        if let items = try? FileManager.default.contentsOfDirectory(at: userLUTsFolder, includingPropertiesForKeys: nil) {
            for url in items where url.pathExtension.lowercased() == "cube" {
                results.append(LUTInfo(name: url.deletingPathExtension().lastPathComponent, url: url))
            }
        }

        return results.sorted { $0.name < $1.name }
    }

    /// يقرأ ملف .cube ويبني فلتر CIColorCube جاهزًا للاستخدام.
    /// ترتيب بيانات .cube (R يتغير أسرع، ثم G، ثم B) يطابق تمامًا الترتيب الذي يتوقعه
    /// CIColorCube، لذلك لا حاجة لإعادة ترتيب البيانات — فقط إضافة قناة Alpha = 1.
    static func makeFilter(from url: URL) -> CIFilter? {
        guard let text = try? String(contentsOf: url, encoding: .utf8) else { return nil }

        var size: Int?
        var values: [Float] = []
        values.reserveCapacity(1000)

        for rawLine in text.split(separator: "\n") {
            let line = rawLine.trimmingCharacters(in: .whitespaces)
            if line.isEmpty || line.hasPrefix("#") { continue }
            let upper = line.uppercased()
            if upper.hasPrefix("LUT_3D_SIZE") {
                let parts = line.split(separator: " ")
                if let last = parts.last, let s = Int(last) { size = s }
                continue
            }
            if upper.hasPrefix("TITLE") || upper.hasPrefix("DOMAIN_") || upper.hasPrefix("LUT_1D_SIZE") {
                continue
            }
            let parts = line.split(separator: " ").compactMap { Float($0) }
            if parts.count == 3 {
                values.append(contentsOf: parts)
            }
        }

        guard let dimension = size, values.count == dimension * dimension * dimension * 3 else {
            return nil
        }

        var cubeData = [Float]()
        cubeData.reserveCapacity(dimension * dimension * dimension * 4)
        var i = 0
        while i < values.count {
            cubeData.append(values[i])       // R
            cubeData.append(values[i + 1])   // G
            cubeData.append(values[i + 2])   // B
            cubeData.append(1.0)             // A
            i += 3
        }

        let data = cubeData.withUnsafeBufferPointer { Data(buffer: $0) }

        guard let filter = CIFilter(name: "CIColorCube") else { return nil }
        filter.setValue(dimension, forKey: "inputCubeDimension")
        filter.setValue(data, forKey: "inputCubeData")
        return filter
    }
}
