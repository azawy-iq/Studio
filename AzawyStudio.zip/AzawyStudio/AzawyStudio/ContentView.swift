import SwiftUI
import PhotosUI
import AVKit
import Photos

struct ContentView: View {
    @State private var pickerItem: PhotosPickerItem?
    @State private var inputURL: URL?
    @State private var outputURL: URL?

    @State private var luts: [LUTInfo] = []
    @State private var selectedLUT: LUTInfo?

    @State private var isolateBackground = true
    @State private var blurRadius: Double = 15

    @State private var isProcessing = false
    @State private var progressValue: Double = 0
    @State private var statusText = ""

    private let processor = VideoProcessor()

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {

                    PhotosPicker(selection: $pickerItem, matching: .videos) {
                        VStack {
                            if let inputURL {
                                VideoPlayer(player: AVPlayer(url: inputURL))
                                    .frame(height: 220)
                                    .cornerRadius(14)
                            } else {
                                RoundedRectangle(cornerRadius: 14)
                                    .strokeBorder(style: StrokeStyle(lineWidth: 2, dash: [6]))
                                    .frame(height: 220)
                                    .overlay(Text("اختر فيديو من مكتبة الصور").foregroundStyle(.secondary))
                            }
                        }
                    }
                    .onChange(of: pickerItem) { newItem in
                        Task { await loadVideo(from: newItem) }
                    }

                    VStack(alignment: .leading, spacing: 14) {
                        Picker("الفلتر السينمائي (LUT)", selection: $selectedLUT) {
                            Text("بدون فلتر").tag(Optional<LUTInfo>.none)
                            ForEach(luts) { lut in
                                Text(lut.name).tag(Optional(lut))
                            }
                        }
                        .pickerStyle(.menu)

                        if luts.isEmpty {
                            Text("لا توجد فلاتر بعد — أضف ملفات .cube إلى مجلد LUTs عبر تطبيق الملفات (على جهازي > Azawy Studio > LUTs)")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }

                        Toggle("عزل الخلفية (تمويه شبيه بعدسات Leica / Sony)", isOn: $isolateBackground)

                        VStack(alignment: .leading) {
                            Text("قوة تمويه الخلفية: \(Int(blurRadius))")
                                .font(.caption)
                            Slider(value: $blurRadius, in: 3...40, step: 1)
                        }
                        .opacity(isolateBackground ? 1 : 0.4)
                        .disabled(!isolateBackground)
                    }
                    .padding()
                    .background(.thinMaterial)
                    .clipShape(RoundedRectangle(cornerRadius: 14))

                    Button {
                        Task { await runProcessing() }
                    } label: {
                        HStack {
                            if isProcessing {
                                ProgressView()
                                Text(statusText.isEmpty ? "جاري المعالجة..." : statusText)
                            } else {
                                Text("معالجة الفيديو")
                            }
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(inputURL == nil || isProcessing)

                    if isProcessing {
                        ProgressView(value: progressValue)
                    }

                    if let outputURL {
                        VStack(spacing: 10) {
                            Text("النتيجة").font(.headline)
                            VideoPlayer(player: AVPlayer(url: outputURL))
                                .frame(height: 220)
                                .cornerRadius(14)

                            Button("حفظ في مكتبة الصور") {
                                Task { await saveToPhotos(outputURL) }
                            }
                            .buttonStyle(.bordered)
                        }
                    }
                }
                .padding()
            }
            .navigationTitle("Azawy Studio")
            .onAppear { luts = LUTManager.discoverLUTs() }
        }
    }

    private func loadVideo(from item: PhotosPickerItem?) async {
        guard let item else { return }
        outputURL = nil
        if let data = try? await item.loadTransferable(type: Data.self) {
            let tempURL = FileManager.default.temporaryDirectory
                .appendingPathComponent(UUID().uuidString)
                .appendingPathExtension("mov")
            try? data.write(to: tempURL)
            inputURL = tempURL
        }
    }

    private func runProcessing() async {
        guard let inputURL else { return }
        isProcessing = true
        progressValue = 0
        statusText = "جاري المعالجة..."
        outputURL = nil

        let lutFilter = selectedLUT.flatMap { LUTManager.makeFilter(from: $0.url) }

        do {
            let result = try await processor.process(
                inputURL: inputURL,
                lutFilter: lutFilter,
                isolateBackground: isolateBackground,
                blurRadius: blurRadius,
                progress: { value in
                    Task { @MainActor in
                        progressValue = value
                    }
                }
            )
            outputURL = result
            statusText = "تمت المعالجة بنجاح"
        } catch {
            statusText = "خطأ: \(error.localizedDescription)"
        }

        isProcessing = false
    }

    private func saveToPhotos(_ url: URL) async {
        do {
            try await PHPhotoLibrary.shared().performChanges {
                PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: url)
            }
            statusText = "تم الحفظ في مكتبة الصور"
        } catch {
            statusText = "تعذر الحفظ: \(error.localizedDescription)"
        }
    }
}

#Preview {
    ContentView()
}
