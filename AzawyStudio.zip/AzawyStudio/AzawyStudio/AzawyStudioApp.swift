import SwiftUI

@main
struct AzawyStudioApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
